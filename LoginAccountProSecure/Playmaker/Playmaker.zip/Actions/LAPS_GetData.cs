// (c) Copyright HutongGames, LLC 2010-2012. All rights reserved.

using UnityEngine;
using System.Collections;

namespace HutongGames.PlayMaker.Actions
{
	[ActionCategory("LAPS")]
	[Tooltip("Get information from the server and save it in a variable.")]
	public class LAPS_GetData : LAPS_Action
	{
		// DATAS SENT
		[RequiredField]
		public FsmString[] datasInThatOrder;
		
		// EXECUTION
		public override void OnEnter()
		{
			laps.Send("GetData", success, fail, null);
		}
		
		// SUCCESS
		public override void success(string[] serverDatas)
		{
			Debug.Log("Count of datas received : "+serverDatas.Length);
			laps.log(serverDatas[0]);							// Show the message on UI (not an error)
			datasInThatOrder[0].Value = serverDatas[1];		// Save the first information received
			datasInThatOrder[1].Value = serverDatas[2];		// Save the second information received
			datasInThatOrder[2].Value = serverDatas[3];		// Save the third information received
			Fsm.Event(successEvent);							// Go to Success
		}
	}
}