﻿// (c) Copyright HutongGames, LLC 2010-2012. All rights reserved.

using UnityEngine;
using System.Collections;
using UnityEngine.UI;

namespace HutongGames.PlayMaker.Actions
{
	[ActionCategory("LAPS")]
	[Tooltip("Load playerPrefs into username and password")]
	public class LoadCredentials : FsmStateAction
	{
		// DATAS
		[RequiredField]
		[Tooltip("Username.")]
		public InputField UsernameField;

		[RequiredField]
		[Tooltip("Password.")]
		public InputField PasswordField;


		public override void OnEnter()
		{
			UsernameField.text = PlayerPrefs.GetString("Username");
			PasswordField.text = PlayerPrefs.GetString("Password");
		}
	}
}