﻿// (c) Copyright HutongGames, LLC 2010-2012. All rights reserved.

using UnityEngine;
using System.Collections;
using UnityEngine.UI;

namespace HutongGames.PlayMaker.Actions
{
	[ActionCategory("UI")]
	[Tooltip("LAPS: Get the text of an UI field.")]
	public class GetUiFieldValue : FsmStateAction
	{
		// DATAS
		[RequiredField]
		[Tooltip("Drag the UI field here.")]
		public InputField field;

		[RequiredField]
		[Tooltip("The variable to store the input string.")]
		public FsmString variable;

		public override void OnEnter()
		{
			variable.Value = field.text;
		}
	}
}