// (c) Copyright HutongGames, LLC 2010-2012. All rights reserved.

using UnityEngine;
using System.Collections;
using System.Collections.Generic;

namespace HutongGames.PlayMaker.Actions
{
	[ActionCategory("LAPS")]
	[Tooltip("Send the information to the server.")]
	public class LAPS_SendData : LAPS_Action
	{
		// DATAS SENT
		[RequiredField]
		public FsmString[] datasToSend;
		
		// EXECUTION
		public override void OnEnter()
		{
			string[] datas = new string[datasToSend.Length];
			for(int i=0; i<datasToSend.Length; i++)
			{
				datas[i] = datasToSend[i].Value;
			}
			
			laps.Send("SendData", success, fail, datas);
		}
		
		// SUCCESS
		public override void success(string[] serverDatas)
		{
			laps.log(serverDatas[0]);		// Show the message on UI (not an error)
			Fsm.Event(successEvent);		// Go to Success
		}
	}
}