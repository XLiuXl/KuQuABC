// (c) Copyright HutongGames, LLC 2010-2012. All rights reserved.

using UnityEngine;
using System.Collections;

namespace HutongGames.PlayMaker.Actions
{
	[ActionCategory("LAPS")]
	[Tooltip("Send the validation email again.")]
	public class LAPS_Resend : LAPS_Action
	{
		// DATAS SENT
		[RequiredField]
		public FsmString username;
		private bool CheckDatas()
		{
			if(username.Value == "") { return false; }
			return true;
		}
		
		// EXECUTION
		public override void OnEnter()
		{
			if(CheckDatas()) // If datas are correct
			{
				string[] datas = new string[1];
				datas[0] = username.Value;
				
				laps.Send("Resend", success, fail, datas);
			}
			else { fail("Reinitialization failed."); } // Raise the fail event if datas are not correct
		}
		
		// SUCCESS
		public override void success(string[] serverDatas)
		{
			laps.log(serverDatas[0]);	// Show the message on UI (not an error)
			Fsm.Event(successEvent);			// Go to Success
		}
	}
}