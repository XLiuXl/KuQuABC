﻿// (c) Copyright HutongGames, LLC 2010-2012. All rights reserved.

using UnityEngine;
using System.Collections;
using System.Collections.Generic;

namespace HutongGames.PlayMaker.Actions
{
	[ActionCategory("LAPS")]
	[Tooltip("Send the information to the server.")]
	public class LAPS_LoadSessionVariables : LAPS_Action
	{
		// SESSION DATAS
		[RequiredField]
		public FsmString Username;
		[RequiredField]
		public FsmString Password;
		[RequiredField]
		public FsmString Session_id;
		[RequiredField]
		public FsmString Session_token;
		
		// EXECUTION
		public override void OnEnter()
		{
			Username.Value = UserSession.username;
			Password.Value = UserSession.password;
			Session_id.Value = UserSession.session_id;
			Session_token.Value = UserSession.session_token;
			success(null);
		}
		
		// SUCCESS
		public override void success(string[] serverDatas)
		{
			Debug.Log("Session variables loaded.");
			Fsm.Event(successEvent);			// Go to Success
		}
	}
}