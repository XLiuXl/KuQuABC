// (c) Copyright HutongGames, LLC 2010-2012. All rights reserved.

using UnityEngine;
using System.Collections;
using System;

namespace HutongGames.PlayMaker.Actions
{
	[ActionCategory("LAPS")]
	[Tooltip("Modify user information.")]
	public class LAPS_Modify : LAPS_Action
	{
		// DATAS SENT
		[RequiredField]
		public FsmString mail;
		[RequiredField]
		public FsmString username;
		[RequiredField]
		public FsmString password;
		[RequiredField]
		public FsmString confirmPassword;
		private bool CheckDatas()
		{
			// Launch register coroutine only if fields are corrects
			if(password.Value != confirmPassword.Value) { laps.log("Your password confirmation do not match."); return false; }
			if(mail.Value.Length>0 && !mail.Value.Contains("@")) { laps.log("Your email address is not valid."); return false; }
			if(password.Value.Length>0 && password.Value.Length<3) { laps.log("Your password must be at least 3 characters long."); return false; }
			
			// Don't send request if no information to update
			if(String.IsNullOrEmpty(mail.Value) && String.IsNullOrEmpty(username.Value) && String.IsNullOrEmpty(password.Value))
			{
				laps.log("No information to update.");
				return false;
			}
			return true;
		}
		
		// EXECUTION
		public override void OnEnter()
		{
			if(CheckDatas()) // If datas are correct
			{
				string[] datas = new string[3];
				datas[0] = mail.Value;
				datas[1] = username.Value;
				datas[2] = UtilsProSecure.hash(password.Value);

				laps.Send("Modify", success, fail, datas);
			}
			else { fail("Modification failed."); } // Raise the fail event if datas are not correct
		}
		
		// SUCCESS
		public override void success(string[] serverDatas)
		{
			laps.log(serverDatas[0]);	// Show the message on UI (not an error)
			if(!String.IsNullOrEmpty(username.Value)) { PlayerPrefs.SetString("username",username.Value); }
			if(!String.IsNullOrEmpty(password.Value)) { PlayerPrefs.SetString("password",password.Value); }
			Fsm.Event(successEvent);			// Go to Success
		}
	}
}