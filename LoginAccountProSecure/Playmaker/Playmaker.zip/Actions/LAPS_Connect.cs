// (c) Copyright HutongGames, LLC 2010-2012. All rights reserved.

using UnityEngine;
using System.Collections;

namespace HutongGames.PlayMaker.Actions
{
	[ActionCategory("LAPS")]
	[Tooltip("Establish SSL connection (RSA & AES security) and connect the user with his username and password.")]
	public class LAPS_Connect : LAPS_Action
	{
		// DATAS SENT
		[RequiredField]
		public FsmString username;
		[RequiredField]
		public FsmString password;
		private bool CheckDatas()
		{
			if(username.Value.Length < 3) { laps.log("Your username must be at least 3 characters long."); return false; }
			if(password.Value.Length < 3) { laps.log("Your password must be at least 3 characters long."); return false; }
			return true;
		}
		
		// EXECUTION
		public override void OnEnter()
		{
			if(CheckDatas()) // If datas are correct
			{
				string[] datas = new string[2];
				datas[0] = username.Value;
				datas[1] = UtilsProSecure.hash(password.Value);
				
				laps.Send("Login", success, fail, datas);
			}
			else { fail("Connection failed."); } // Raise the fail event if datas are not correct
		}
		
		// SUCCESS
		public override void success(string[] serverDatas)
		{
			laps.log(serverDatas[0], true, false);				// Show the message on UI
			UserSession.session_id = serverDatas[1];			// Save SID the server gave us
			UserSession.loggedIn = true;						// Set the flag saying the user is logged in correctly
			UserSession.username = username.Value;				// Save login
			UserSession.password = password.Value;				// Save password
			PlayerPrefs.SetString("Username", username.Value);	// Save playerPrefs
			PlayerPrefs.SetString("Password", password.Value);	// Save playerPrefs
			Fsm.Event(successEvent);							// Go to Success
		}
	}
}